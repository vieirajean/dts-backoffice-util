// Array de posições.
export const PO_CONTROL_POSITIONS = [
    'right',
    'right-top',
    'right-bottom',
    'top',
    'top-left',
    'top-right',
    'left',
    'left-top',
    'left-bottom',
    'bottom',
    'bottom-left',
    'bottom-right'
];
