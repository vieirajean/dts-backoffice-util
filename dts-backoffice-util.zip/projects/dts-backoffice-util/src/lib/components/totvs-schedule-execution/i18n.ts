export const pt = {

    applications: 'Application',
};

export const en = {

    applications: 'Application',
};

export const es = {

    applications: 'Application',
};
