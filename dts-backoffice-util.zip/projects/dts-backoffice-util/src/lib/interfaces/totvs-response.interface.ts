export interface TotvsResponse<T> {
    items: T[];
    hasNext?: boolean;
}
